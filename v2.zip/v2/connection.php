<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('Asia/Calcutta'); 
$mysql = mysqli_connect('localhost:3306','paragon_app','PEcSkrGcvIB?','paragon_app');
if(!$mysql){
    http_response_code(502);
    $responce = array(
        'status' => 'false',
        'response_code' => '502',
        'task_status' => 'false',
        'message' => 'Bad Gateway'
    );
    echo json_encode($responce);
    exit;
}